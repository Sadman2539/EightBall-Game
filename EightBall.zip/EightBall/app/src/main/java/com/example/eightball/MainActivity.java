package com.example.eightball;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button askButton;
    private ImageView ballImage;
    final int[] imageArray = {
            R.drawable.ball1,
            R.drawable.ball2,
            R.drawable.ball3,
            R.drawable.ball4,
            R.drawable.ball5};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Finding Button,ImageView by id

        askButton = findViewById(R.id.askButtonID);
        ballImage = findViewById(R.id.eightBallImageID);

        //Setting onClickListener to the button
        askButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random randomNumberGenerator = new Random();
                final int randomNumber = randomNumberGenerator.nextInt(5);
                ballImage.setImageResource(imageArray[randomNumber]);
            }
        });
    }
}